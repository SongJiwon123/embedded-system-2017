#include <stdio.h>

void mywrite(void);
void myread(void);
