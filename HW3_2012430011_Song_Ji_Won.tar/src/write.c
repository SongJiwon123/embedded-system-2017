#include "io.h"

void mywrite (void)
{
	printf("my write called\n");
}
