#include "io.h"

int main (void)
{
	mywrite();
	myread();
	return 0;
}
