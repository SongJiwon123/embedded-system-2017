#include "io.h"

void myread (void)
{
	printf("my read called\n");
}
